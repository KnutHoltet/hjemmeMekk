import java.util.HashMap;

/*
OPPGAVE 7
 */

public class LeseTrad implements Runnable{
    Monitor1 monitor;
    String fil;
    public LeseTrad(Monitor1 monitor, String fil){
        this.monitor = monitor;
        this.fil = fil;
    }

    @Override
    public void run(){
        HashMap<String, Subsekvens> map = monitor.lesFraFil(fil);
        monitor.settInn(map);
    }
}