/*
OPPGAVE 1
 */
class Subsekvens {
    public final String subsekvens;
    private int antall;

    public Subsekvens(String subsekvens){
        this.subsekvens = subsekvens;
        antall = 1;
    }

    public String hentSubsekvens(){
        return this.subsekvens;
    }

    public int endreAntall(int antall){
        return this.antall += antall;
    }

    public String toString(){
        return String.format("(%s,%s)", this.subsekvens, this.antall);
    }

    /*
    TILEGG TIL OPPGAVE 4
     */

    public int hentAntall(){
        return this.antall;
    }
}