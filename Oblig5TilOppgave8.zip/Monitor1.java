
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/*
OPPGAVE 6
 */

public class Monitor1 {
    SubsekvensRegister register;
    public Monitor1(SubsekvensRegister register){
        this.register = register;
    }
    Lock laas = new ReentrantLock();

    public void settInn(HashMap<String, Subsekvens> map){
        laas.lock();
        try{
            register.settInn(map);
        }finally{
            laas.unlock();
        }
    }

    public HashMap<String, Subsekvens> taUt(){
        return register.taUt();
    }

    public HashMap<String, Subsekvens> lesFraFil(String fil){
        laas.lock();
        try{
            return SubsekvensRegister.lesFil(fil);
        }finally{
            laas.unlock();
        }
    }

    public int antHashMaps(){
        laas.lock();
        try{
            return register.antallSubsekvenser();
        }finally{
            laas.unlock();
        }
    }

    public ArrayList<HashMap<String, Subsekvens>> hentListe(){
        laas.lock();
        try{
            return register.hentSubsekvenser();
        }finally{
            laas.unlock();
        }
    }
}