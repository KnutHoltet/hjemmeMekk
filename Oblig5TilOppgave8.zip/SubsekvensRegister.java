import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/*
OPPGAVE 2
 */
class SubsekvensRegister {
    ArrayList<HashMap<String, Subsekvens>> subsekvenser = new ArrayList<>();

    public void settInn(HashMap<String, Subsekvens> hashMap){
        subsekvenser.add(hashMap);
    }

    public HashMap<String, Subsekvens> taUt(){
        return subsekvenser.get(0);
    }

    public int antallSubsekvenser(){
        return subsekvenser.size();
    }

    /*
    OPPGAVE 3
     */

    public static HashMap<String, Subsekvens> lesFil(String sti){
        HashMap<String, Subsekvens> immunrepertoar = new HashMap<>();

        File fil;
        Scanner scan = null;

        try{
            fil = new File(sti);
            scan = new Scanner(fil);
        }catch(FileNotFoundException e){
            System.out.println("Fil ikke funnet" + e);
        }

        while(scan.hasNext()){
            String DNAsekvens= scan.nextLine();
            while(DNAsekvens.length() >= 3){
                String subsekvens = DNAsekvens.substring(0,3);
                Subsekvens immunreseptor = new Subsekvens(subsekvens);
                immunrepertoar.put(subsekvens, immunreseptor);


                int lengde = DNAsekvens.length();
                DNAsekvens = DNAsekvens.substring(1);
            }
        }

        return immunrepertoar;
    }

    /*
    OPPGAVE 4
     */

    public static HashMap<String, Subsekvens> flett(HashMap<String, Subsekvens> mapEn, HashMap<String, Subsekvens> mapTo){
        for(String key : mapTo.keySet()){
            if(mapEn.containsKey(key)){
                //Dersom den sekvensen finnes
                Subsekvens finnes = mapEn.get(key);
                Subsekvens s = mapTo.get(key);
                int antallFraMapTo = s.hentAntall();

                finnes.endreAntall(antallFraMapTo);
            }

            else{
                mapEn.put(key, mapTo.get(key));
            }
        }
        return mapEn;
    }

    //Test metode for aa sjekke om listen er riktig!
    public ArrayList<HashMap<String, Subsekvens>> hentSubsekvenser(){
        return subsekvenser;
    }
}
